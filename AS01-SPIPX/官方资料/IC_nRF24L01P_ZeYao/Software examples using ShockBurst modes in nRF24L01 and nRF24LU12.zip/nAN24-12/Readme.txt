This readme file describes the content of the archive file "nAN24-12.zip"

Folder "Documents" contains the nAN24-12 application note.
Folder "Code" contains the code that is described by application note nAN24-12